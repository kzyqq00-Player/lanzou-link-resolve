import * as types from 'lanzou-link-resolve';
import * as https from 'node:https';
import { JSDOM , DOMWindow } from 'jsdom';

export const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0';
export const accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7';
export const acceptLanguage = 'zh-CN,zh;q=0.9';

function isEmpty(val: any) {
    return val === '' || Object.keys(val).length === 0 || val === null || val === undefined;
}

class LinkResolveError extends Error {
    constructor(message?: string, code?: LinkResolveErrorCodes, data?: any) {
        super(message);
        this.code = code;
        this.data = data;
    }

    public data?: any;
    public code?: number;
}

export enum LinkResolveErrorCodes {
    UNKNOWN_AJAXM_PHP_RESPONSE_EXCEPTION = -1,
    PASSWORD_REQUIRED = 1,
    PASSWORD_INCORRECT = 2,
}

export function getBytesFromFilesizeString(filesize: string) {
    filesize = filesize.replace(/\s+/, '');
    const num = parseFloat(filesize.slice(0, -1));
    const unit = filesize.slice(-1).toUpperCase();

    switch (unit) {
        case 'B': return num;
        case 'K': return Math.floor(num * 1024);
        case 'M': return Math.floor(num * 1024 * 1024);
        case 'G': return Math.floor(num * 1024 * 1024 * 1024);
        case 'T': return Math.floor(num * 1024 * 1024 * 1024 * 1024);
        default: throw new Error('你确定蓝奏云能存这么大文件?');
    }
}

export class LinkResolver {
    constructor(options: types.ResolveOptions) {
        // 初始化处理
        Object.setPrototypeOf(options, null);


        if (typeof options.url === 'string') {
            options.url = new URL(options.url);
        }

        this.options = Object.freeze(options) as Readonly<types.ProcessedResolveOptions>;
    }

    protected window: DOMWindow;
    protected options: Readonly<types.ProcessedResolveOptions>;

    public async resolve() {
        const requestURL = new URL(this.options.url.pathname, 'https://www.lanzoup.com');
        const result = new Proxy<types.ResolveResult>({
            downURL: '',
            filename: '',
            filesize: 0
        }, {
            set(obj, prop, val, receiver) {
                if (prop === 'downURL' && typeof val === 'string') {
                    return Reflect.set(obj, prop, new URL(val), receiver);
                } else {
                    // @ts-expect-error
                    return Reflect.set(...arguments);
                }
            }
        });
        
        const html = await (await fetch(requestURL, {
            headers: {
                accept,
                "accept-language": acceptLanguage,
                "accept-encoding": 'gzip, deflate',
                "user-agent": userAgent,
                connection: 'keep-alive'
            },
            method: 'GET'
        })).text();

        this.window = new JSDOM(html).window;

        const filenameFromTitle = this.window.document.title.slice(0, -6);
        const filesizeFromMetaDescription = (this.window.document.querySelector('meta[name="description"]') as HTMLMetaElement)?.content?.slice?.(5);
        if (this.window.document.querySelector('#pwd')) {
            if (isEmpty(this.options.password)) {
                throw new LinkResolveError('Password required', LinkResolveErrorCodes.PASSWORD_REQUIRED);
            }

            result.filesize = getBytesFromFilesizeString(
                this.window.document.querySelector('.n_filesize')?.textContent?.slice?.(3)
                ?? filesizeFromMetaDescription
            );
            const resp: types.AjaxmPHPResponse = await (await fetch('https://www.lanzoup.com/ajaxm.php', {
                headers: {
                    "content-type": 'application/x-www-form-urlencoded'
                },
                body: `action=downprocess&sign=${html.match(/^skdklds\s+=\s+'(.*?)'$/)[1]}&p=${this.options.password}`,
                method: 'POST'
            })).json();
            if (resp.zt) {
                result.downURL = new URL('/file/?' + resp.url, resp.dom);
                result.filename = resp.inf;
            } else {
                if (resp.inf === '密码不正确') {
                    throw new LinkResolveError('Password incorrect', LinkResolveErrorCodes.PASSWORD_INCORRECT);
                } else {
                    throw new LinkResolveError('Unknwon ajaxm.php response exception', LinkResolveErrorCodes.UNKNOWN_AJAXM_PHP_RESPONSE_EXCEPTION, resp);
                }
            }
        }

        result.filename =
            this.window.document.querySelector('.d')?.firstChild?.textContent
            || filenameFromTitle
            || undefined;
    }
}